function validate() {

    var mail = document.getElementById("email");
    var pass = document.getElementById("password");

    // Email validation

    var mailMatch = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

    if (mail.value.trim() == "") {
        setErrorFor(email, 'Email connot be blank');
        return false;
    }

    else {
        if (!mail.value.match(mailMatch)) {
        setErrorFor(email, 'Email format is invalid');
        return false;
         }

        else {
            setSuccessFor(email);
        }
    }

   // Password Validation

    if (pass.value.trim() == "") {
        setErrorFor(password, 'Password connot be blank');
        return false;
    }

    else {

        var lowerCaseLetters = /[a-z]/g;
        var upperCaseLetters = /[A-Z]/g;
        var characters = /[!@#$%^&*()_=+-.,]/g;
        var numbers = /[0-9]/g;


        if(!pass.value.match(lowerCaseLetters)) 
        { 
            setErrorFor(pass, "Must include at least one lowercase letter");
            return false;
        }

        if(!pass.value.match(upperCaseLetters)) 
        { 
            setErrorFor(pass, "Must include at least one uppercase letter");
            return false;
        }

        if(!pass.value.match(lowerCaseLetters)) 
        { 
            setErrorFor(pass, "Must include least one lower case letter");
            return false;
        }

        if(!pass.value.match(characters)) 
        { 
            setErrorFor(pass, "Must include at least one special character");
            return false;
        }

        if(!pass.value.match(numbers)) 
        { 
            setErrorFor(pass, "Must include at least one number");
            return false;
        }
        
        if(pass.value.length < 8) {
            setErrorFor(pass, "Must contain 8 or more characters");
            return false;
        }

        else {
            setSuccessFor(pass);
        }
    }

    return true;
}

//message function

function setErrorFor(input, message) {
    var formControl = input.parentElement;
    var small = formControl.querySelector("small");
    small.innerText = message;
    formControl.className = "form-control error";
    input.focus();
}

function setSuccessFor(input) {
    var formControl = input.parentElement;
    formControl.className = 'form-control success';
}   
