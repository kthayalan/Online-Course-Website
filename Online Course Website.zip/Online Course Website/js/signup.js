function validate() {

    var firstname = document.getElementById("fname");
    var lastname = document.getElementById("lname");
    var mail = document.getElementById("email");
    var pass1 = document.getElementById("password1");
    var pass2 = document.getElementById("password2");

    // First name validation
    var nameMatch = /^[a-zA-Z]{2,30}$/g;

    if (firstname.value.trim() == "") {
        setErrorFor(fname, 'First Name connot be blank');
        return false;
    }

    else if(firstname.value.length < 2 || firstname.value.length > 30) {
        setErrorFor(fname, "First name length is 2 to 30");
        return false;
    }

    else {
        if(!firstname.value.match(nameMatch)) 
        { 
            setErrorFor(fname, "First Name must only be letter");
            return false;
        }

        setSuccessFor(fname);
        
    }

    // Last name validation

    if (lastname.value.trim() == "") {
        setErrorFor(lname, "Last Name connot be blank");
        return false;
    }

    else if(lastname.value.length < 2 || lastname.value.length > 30) {
        setErrorFor(lname, "Last name length is 2 to 30");
        return false;
    }

    else {
        if(!lastname.value.match(nameMatch)) 
        { 
            setErrorFor(lname, "Last Name must only be letter");
            return false;
        }

        setSuccessFor(lname);
        
    }

    // Email validation

    var mailMatch = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

    if (mail.value.trim() == "") {
        setErrorFor(email, 'Email connot be blank');
        return false;
    }

    else {
        if (!mail.value.match(mailMatch)) {
        setErrorFor(email, 'Email format is invalid');
        return false;
         }

        else {
            setSuccessFor(email);
        }
    }

   // Password1 Validation

    if (pass1.value.trim() == "") {
        setErrorFor(password1, 'Password connot be blank');
        return false;
    }

    else {

        var lowerCaseLetters = /[a-z]/g;
        var upperCaseLetters = /[A-Z]/g;
        var characters = /[!@#$%^&*()_=+-.,]/g;
        var numbers = /[0-9]/g;


        if(!pass1.value.match(lowerCaseLetters)) 
        { 
            setErrorFor(pass1, "Must contain at least one lowercase letter");
            return false;
        }

        if(!pass1.value.match(upperCaseLetters)) 
        { 
            setErrorFor(pass1, "Must contain at least one uppercase letter");
            return false;
        }

        if(!pass1.value.match(lowerCaseLetters)) 
        { 
            setErrorFor(pass1, "Must contain least one lower case letter");
            return false;
        }

        if(!pass1.value.match(characters)) 
        { 
            setErrorFor(pass1, "Must contain at least one special character");
            return false;
        }

        if(!pass1.value.match(numbers)) 
        { 
            setErrorFor(pass1, "Must contain at least one number");
            return false;
        }
        
        if(pass1.value.length < 8) {
            setErrorFor(pass1, "Must contain 8 or more characters");
            return false;
        }

        else {
            setSuccessFor(pass1);
        }
    }

    // Password2 Validation

    if (pass2.value.trim() == "") {
        setErrorFor(password2, 'Password connot be blank');
        return false;
    }

    else {

        var lowerCaseLetters = /[a-z]/g;
        var upperCaseLetters = /[A-Z]/g;
        var characters = /[!@#$%^&*()_=+-.,]/g;
        var numbers = /[0-9]/g;


        if(!pass2.value.match(lowerCaseLetters)) 
        { 
            setErrorFor(pass2, "Must contain at least one lowercase letter");
            return false;
        }

        if(!pass2.value.match(upperCaseLetters)) 
        { 
            setErrorFor(pass2, "Must contain at least one uppercase letter");
            return false;
        }

        if(!pass2.value.match(lowerCaseLetters)) 
        { 
            setErrorFor(pass2, "Must contain least one lower case letter");
            return false;
        }

        if(!pass2.value.match(characters)) 
        { 
            setErrorFor(pass2, "Must contain at least one special character");
            return false;
        }

        if(!pass2.value.match(numbers)) 
        { 
            setErrorFor(pass2, "Must contain at least one number");
            return false;
        }
        
        if(pass2.value.length < 8) {
            setErrorFor(pass2, "Must contain 8 or more characters");
            return false;
        }

        else {
            setSuccessFor(pass2);
        }
    }

    // compare password1 and password2

    if (!(pass1.value == pass2.value)) {
        setErrorFor(pass1, "Password is not match");
        setErrorFor(pass2, "Password is not match");
        return false;
    }
            
    return true;
}

// messsage functions

function setErrorFor(input, message) {
    var formControl = input.parentElement;
    var small = formControl.querySelector("small");
    small.innerText = message;
    formControl.className = "form-control error";
    input.focus();
}

function setSuccessFor(input) {
    var formControl = input.parentElement;
    formControl.className = 'form-control success';
}   
